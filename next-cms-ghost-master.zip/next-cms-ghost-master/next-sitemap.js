module.exports = {
  // see https://github.com/iamvishnusankar/next-sitemap
  siteUrl: 'https://next.jamify.org',
  generateRobotsTxt: true,
  sitemapSize: 7000,
}
